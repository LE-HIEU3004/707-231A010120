// File JS chung, có thể thêm logic mở rộng
console.log("JS script loaded!");
